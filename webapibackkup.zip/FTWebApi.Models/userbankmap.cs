﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FTWebApi.Models
{
    public class userbankmap
    {
        public string UserId { get; set; }
        public string Bank { get; set; }
        public string QueryType { get; set; }
        public string UserPriority  { get; set; }
    }

}

