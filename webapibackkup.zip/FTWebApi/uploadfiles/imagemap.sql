select top 10 * from businesscalllog where gendate='2021-8-24' and custcustomercode='C0095593'

select top 10 * from ImageMapper where bclid=32542676

select top 100 * from ImageMapper_1 where bclid=32542676

35414070
select top 10 * from ImageMapper_history where callno=36571201
where bclid=32542676

where callno=36571201
where bclid=33198601
