EmailBody_2021-06-25_104528_799404.html

'Z:\RCMEmail_Files\2021_06_25\EmailBody_2021-06-25_104528_799404.html'

'\\172.19.100.157\nfsrmsuat\RCMEmail_Files\2021_06_25\EmailBody_2021-06-25_104528_799404.html'

'\\172.19.100.157\nfsmount\RCMEmail_Files\2021_06_25\EmailBody_2021-06-25_104528_799404.html'

EXEC xp_cmdshell 
 'NET USE Z: \\172.19.100.157\ nfsmount  /USER:Administrator abc@123 /PERSISTENT:yes'



select * from ticket order by ticketid desc

select * from ticket where ticketid='T000264'

select * from batch where batchid='B000175'

update batch set emailbody='\\172.19.100.157\nfsmount\RCMEmail_Files\2021_06_25\EmailBody_2021-06-25_104528_799404.html'  where batchid='B000175'

update batch set emailbody='F:\rcmquery\EmailBody_2021-06-25_104533_034799.html' where batchid='B000175'

select filepath,filename,* from ticket where ticketid='T000264'

EmailBody_2021-06-25_104528_799404.html

update ticket set filepath='F:\arvind\rcmwebapi\FTWebApi\pyload.txt',filename='paload.txt'  where ticketid='T000264' 