select top 10 * from BusinessCallLog where gendate='2021-8-23' and custcustomercode='C0104284'

4114565

BIH_BHA_1019_1


select top 10 * from RouteDispatcherDeno2000.dbo.RouteResourceDtl where routeid='BIH_BHA_1019_1'




select top 10 * from ImageMapper where bclid=33198601

35414070
select top 10 * from ImageMapper_history where callno=35414070
where bclid=33198601



select top 10 * from usermaster where loginid='admin'

update usermaster  set islocked = 0,attemptcount=0 where loginid='admin'